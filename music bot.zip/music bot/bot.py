# 1. First Command
# To Run The Command:
# Type: /analyzeSong
# After typing that you can either input the title and the artist as shown:
# /analyzeSong Time - Pink Floyd

# 2. Second Command
# To Run The Command:
# Type: /recentSongs
# After typing that you will recieve a list of each song you have analyzed from /analyzeSong
# You can also use /recentSongs 1-10 to get a specific list
# This will be important later

# 3. Third Action
# After gathering a list of songs
# Close the Discord bot and open up analyze.py
# analyze.py will then use the songs.db data to create graphs using all of the song data
# And thats about it


# imports
import discord
from discord.ext import commands
import requests
import logging
import sqlite3
from dotenv import load_dotenv
import os

# turn on logging
load_dotenv("3510.env")
logging.basicConfig(level=logging.INFO)

# discord token
TOKEN = os.getenv("DISCORD_TOKEN")

# bot intents
intents = discord.Intents().all()

# bot object instantiated from discord module
bot = commands.Bot(command_prefix="/",intents=intents)
# command_prefix is the character that lets discord know that you're talking to this bot

@bot.event 
async def on_ready(): # tells discord to run this function when the bot logs in
    initialDB() # makes sure the analyzed_songs table exists before the bot tries to use it
    channel = discord.utils.get(bot.get_all_channels(),name="general") # looks through all channels until it finds general
    if channel: # check to make sure the channel exists
        await channel.send("Music Helper is Online") # await is the keyword that tells python to wait until it is time to execute this code
    print(f"{bot.user.id} {bot.user.name} has connected to Discord.") # message to know the bot has successfully joined
    
# SQLITE setup using notes and https://docs.python.org/3/library/sqlite3.html
songDB = "songs.db" # sets the name of the SQLite database file I will use

def initialDB(): # function to make sure the database and table exist before using
    dbConnection = sqlite3.connect(songDB) # opens a connection to songs.db database file also creates one if it dosent exist
    curse = dbConnection.cursor() # creates a cursor object that runs SQL commands
    
    results = curse.execute("SELECT name FROM sqlite_master WHERE name = 'analyzed_songs'").fetchone()
    # checks the sqlite_master table to see if the analzyed_songs table exists
    # sqlite_master is something found in the documenation which basically stores all table names and info inside the database
    # it also allows you to check if the table exists without modifying anything 
    # fetchone returns the name if it exists

    if results is None: # if nothing was returned, it means it dosent exist
        curse.execute("CREATE TABLE analyzed_songs(Title, Artist, Tempo, Energy, Valence)")
        # creates the analyzed_songs table with columns for each of my variables
    dbConnection.commit() # saves any changes to the database
    dbConnection.close() # closes the connection

def savedDB(songInfo): # saves one analyzed song to the database
    dbConnection = sqlite3.connect(songDB) # opens a connection to songs.db database file also creates one if it dosent exist
    curse = dbConnection.cursor() # creates a cursor object that runs SQL commands
    
    curse.execute( # uses the cursor to runs commands
        "INSERT INTO analyzed_songs (Title, Artist, Tempo, Energy, Valence) "
        # tells SQLIte to add data into analyzed_songs table and lists the columns that are being filled
        "VALUES (?, ?, ?, ?, ?)", # the ? are empty slots that will be replaced with values below, found in the documentation
        (
            songInfo["Title"], # takes the song name using title
            songInfo["Artist"], # takes the artist name string using artists
            songInfo["Tempo"], # takes the tempo number
            songInfo["Energy"], # takes teh energy score
            songInfo["Valence"] # takes the valence score
        )
    )
    dbConnection.commit() # saves any changes to the database
    dbConnection.close() # closes the connection

# SQLite Helper to read recent songs
def recentSONGS(limit = 5): # gets the most recent songs up to the number limit
    dbConnection = sqlite3.connect(songDB) # opens a connection to songs.db database file also creates one if it dosent exist
    curse = dbConnection.cursor() # creates a cursor object that runs SQL commands

    curse.execute( # uses the cursor to runs commands
        "SELECT Title, Artist, Tempo, Energy, Valence " # tells SQLite to give back these 5 values from every row in the table
        "FROM analyzed_songs " # tells SQLite to use analyzed_songs table 
        "ORDER BY rowid DESC LIMIT ?", # sorts the rows from newest to oldest using rowid found in the documentation
        # uses ? where the number of rows will be inserted, found in the documentation
        (limit,) # puts the limit value into the ? placeholder also found in the documentation
    )
    songROWS = curse.fetchall() # grabs all the rows returned from the query into a list using fetachall
    dbConnection.close() # closes the connection

    return songROWS # sends the list of recent song rows back, so the discord bot can build a message from them

# spotify token
def spotifyToken(): # function for spotify access token
    client_id = "a38f245fab264fcba4a32dce5e66d1c1" # spotify client
    client_secret = "2e69da1dfee74f8e8c4ee77543b30102" # spotify secret

    url = "https://accounts.spotify.com/api/token"
    # the url request to get the token
    body = {"grant_type": "client_credentials"}
    # body parameters for the request
    response = requests.post(url, data=body, auth=(client_id, client_secret))
    # sends a post request with the client id and the secret
    response_json = response.json()
    # converts the spotify response to json (python dict)
    return response_json["access_token"]
    # returns that access token
    
def spotifyTrack(title, artist=None): # function that searches spotify songs using its title and artist if its provided
    token = spotifyToken() # fresh spotify access token to use the API
    headers = {"Authorization": f"Bearer {token}"} # headers for the Spotify requests with the token
    if artist is None: # checks if there is no artist name
        query = "track:" + title # creates a search string that tells spotify to look for the song using only the title
    else: # if the artist is provided 
        query = "track:" + title + " artist:" + artist # searches for the song using title and artist

    url = "https://api.spotify.com/v1/search"
    # stores spotify's endpoint url
    params = {"q": query, "type": "track", "limit": 1}
    # builds the query parameters for every search
    response = requests.get(url, headers=headers, params=params)
    # sends a get request for the url, headers, and parameters
    data = response.json()
    # converts the data into a json for later
    if not data["tracks"]["items"]: # if no tracks are found returns none
        return None
    tracks = data["tracks"]["items"][0] # grabs the first song found

    artist_names = [] # empty list for artist names
    for a in tracks["artists"]: # loops through each artist object in artists
        artist_names.append(a["name"]) # for every artist pulled, it pulls a name and adds it to artist_names
    artist_string = ", ".join(artist_names) # takes the list of artist names and joins them into one singular string

    return {
        "id": tracks["id"], # returns the spotify track id
        "title": tracks["name"], # returns the spotify track title
        "artists": artist_string # combines the artist strings
    }
    # returns a dictionary of the songs spotify ID, title, and artists all combined into a string
    
def reccobeatsAF(spotifyID): # function that gets audio features from reccobeats using spotify track ids
    url = "https://api.reccobeats.com/v1/track"
    # stores reccobeats endpoint url
    params = {"ids": spotifyID}
    # tells reccobeats what spotify track id information I need
    response = requests.get(url, params=params)
    # sends a get request to reccobeats using the url and track id
    track = response.json()
    # converts the api response into a json
    rbTRACK = track["content"][0] # reccobeats returns a list under content, so this grabs the first track from that list
    rbID = rbTRACK["id"] # grabs the reccobeats track id from that info
    
    url = "https://api.reccobeats.com/v1/track/" + rbID + "/audio-features"
    # builds the link to get the audio features
    response = requests.get(url)
    # sends a get request for that url
    features = response.json()
    # converts the response into a json
    return {
        "tempo": features["tempo"],
        "energy": features["energy"],
        "valence": features["valence"]
    }
    # dictionary that contains tempo, energy and valence values from the features in json.
    
def songFeatures(title, artist=None): # function that gets the songs details and audio features using a title or an artist 
    
    song = spotifyTrack(title, artist) # uses the spotify search function to get the song id, title, and artist

    if song is None: # if the song dosen't exist
        return None
        
    afeature = reccobeatsAF(song["id"]) #uses spotify ID from the song to get tempo, energy, and valence from reccobeats

    return {  
        "Title": song["title"],
        "Artist": song["artists"],
        "Tempo": afeature["tempo"],
        "Energy": afeature["energy"],
        "Valence": afeature["valence"]
    }
    # dictionary that combines spotify song information with reccobeats audio features 
    
def songMood(tempo, energy, valence):
    # https://developer.spotify.com/documentation/web-api/reference/get-audio-features
    # this is where I got all of my documentation for how tempo, energy, and valence, are distributed.
    if tempo < 80: # if tempo is under 80bpm its slow
        tempoDESC = "Slow"
    elif tempo < 120: # if its between 80 and 120 bpm its mid
        tempoDESC = "Mid Tempo"
    else: # everything above 120 bpm is fast
        tempoDESC = "Fast"

    if energy < 0.3: # if energy is under 0.3 is low
        energyDESC = "Low Energy"
    elif energy < 0.7: # if energy is between 0.3 and 0.7 its energetic
        energyDESC = "Energetic"
    else: # anything above 0.7 is very energetic
        energyDESC = "Very Energetic"

    if valence < 0.3: # if valence is under 0.3 its deep or sad
        valenceDESC = "Deep"
    elif valence < 0.7: # if its between 0.3 and 0.7 its moody
        valenceDESC = "Moody"
    else: # anything above 0.7 is considered happy
        valenceDESC = "Happy"

    return tempoDESC + ", " + energyDESC + ", and " + valenceDESC + "."
    # returns a sentence that combines tempo, energy, and valence, as its descriptions

@bot.command(brief = "analyze a song's mood") # tells discord this function is a command users can run using /analyzeSong
async def analyzeSong(ctx, *args): # defines the command functions
    # ctx is the message context (basically where to reply to)
    # args collects every word the user types after the command

    query = " ".join(args)

    if len(args) == 0: # checks if the user typed the command without adding any words after
        await ctx.send ("Please include a song title: /analyzeSong Time - Pink Floyd") # tells the user to include a song
        return 
    # joins all the words into one string
    if "-" in query: # if the user writes - between title and artist
        parts = query.split("-",1) # splits the text into two pieces at the first dash and stores them in a list
        title = parts[0].strip() # takes the first piece (before the dash) and removes extra spaces
        artist = parts[1].strip() # takes the second piece (after the dash) and removes extra spaces
        # 0 index is before the dash
        # 1 index is after the dash
    else:
        title = query.strip() # if there was no dash
        artist = None # sees it as the whole song title and tries to find most popular artist associated

    await ctx.send("Analyzing " + title + "...") # tells the user the discord bot is trying to analyze the song
    
    information = songFeatures(title, artist) # calls the function to get spotify and reccobeats data for that song

    if information is None: # if the song isn't found the bot will print:
        await ctx.send("Sorry, I couldnt find that song on Spotify. Please try another!")
        
    savedDB(information) # saves the song data into songs.db
    
    mood = songMood(information["Tempo"], information["Energy"], information["Valence"])
    # creates a description using tempo, energy and valence to create a mood description

    await ctx.send( # waits for discord to send a message back to general
        "Title: " + information["Title"] + "\n" + # adds the word title, with the song title and \n removes the next line
        "Artist: " + information["Artist"] + "\n" + # same thing but with artist
        "Tempo: " + str(information["Tempo"]) + " BPM\n" + # adds the word tempo, with the bpm number thats converted to text
        "Energy: " + str(information["Energy"]) + "\n" + # adds the word energy, with the energy score and uses \n to move to the next line
        "Valence: " +str(information["Valence"]) + "\n" + # same thing for valence
        "Mood: " + mood # the final mood description
    )
# Recent Songs command
@bot.command(brief = "show recently analyzed songs") # tells discord this function is a command users can run using /recentSongs
async def recentSongs(ctx, limit: int = 5): # creates bot command and sets the default number of songs to 5
    
    if limit < 1: # stops the user from asking for less than 1 song
        limit = 1
    if limit > 10: # stops the user from asking for more than 10 songs
        limit = 10

    rows = recentSONGS(limit) # calls the database and gets song rows from SQLite

    if rows == []: # first check if the list from the database is empty
        rows = None # returns none

    if rows is None: # if there are no songs saved
        await ctx.send("No songs have been analyzed and saved yet.") # bot prints this message
        return # then stops

    message = "Here are the most recently analyzed songs:\n" # starts the string that holds the message the bot sends
    count = 1 # creates a counter for each song
    for row in rows: # for loop to go through each row returned from SQLite
        message = message + str(count) + ". " + row[0] + " - " + row[1] + "\n"
        # adds the song title and artist to the message 
        message = message + " Tempo: " + str(row[2]) + " BPM\n" # adds tempo number to its own line 
        message = message + " Energy Score: " + str(row[3]) + "\n" # adds the energy score to its own line
        message = message + " Valence Score: " + str(row[4]) + "\n\n" # adds the valence score and a blank line right after to make it look nicer for spacing
        # row[2] and so on represents the index number, each of them are assigned a row position when it is printed in discord
        
        count = count + 1 # increases the counter by 1 for each song added
    await ctx.send(message) # sends the completed message back to #general

    
bot.run(TOKEN) # starts the discord bot