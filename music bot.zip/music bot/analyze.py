# imports
import sqlite3
import seaborn as sb
import pandas as pd
import matplotlib.pyplot as plt

songDB = "songs.db" # stores the name of the SQLite database file I will use for song data
dbConnection = sqlite3.connect(songDB) # opens a connection to songs.db database file also creates one if it dosent exist
curse = dbConnection.cursor() # creates a cursor object that runs SQL commands

curse.execute("SELECT Title, Artist, Tempo, Energy, Valence FROM analyzed_songs") # uses SQL to grab these all of the song data 

rows = curse.fetchall() # pulls all of the rows into a list to loop through later
dbConnection.close() # closes the database 

if rows is None: # checks for if the query returns nothing and prints
    print("No songs in the databse yet. Use /analyzeSong in Discord first.")
    quit() # stops the program
# quit functions the same as .quit which is used in the documentation and notes, but is mainly used for interactive scripts.
if len(rows) == 0: # second check for if the result list is empty and prints
    print("No songs in the databse yet. Use /analyzeSong in Discord first.")
    quit() # stops the program
# prints how many songs were successfully loaded so we can see the dataset size
print("Loaded "+ str(len(rows)) + " songs from the database.") 
print("First couple of rows:") # prints a preview message for the first few rows

limit = len(rows) # sets a limit thats equal to how many rows there are
if limit > 5: # sets a cap to five songs so it dosent spam/crash
    limit = 5 

for i in range(limit): # for loop to print out each of the first few rows to see the raw data
    print(rows[i]) # prints the rows

tempo = [] # empty list for tempo in graphs
energy = [] # empty list for energy in graphs
valence = [] # empty list for valence in graphs

for row in rows: # loops through each song in the database
    tempo.append(row[2]) # takes tempo from each row (index 2) and adds it to the tempo list 
    energy.append(row[3]) # takes energy from each row (index 3) and adds it to the energy list
    valence.append(row[4]) # takes valence from each row (index 4) and adds it to the valence list

df= pd.DataFrame() # empty pandas dataframe so the graph data will be more organized
df["Tempo"] = tempo # adds a column for tempo
df["Energy"] = energy # adds a column for energy
df["Valence"] = valence # adds a column for valence

sb.relplot(x="Energy", y="Valence",data=df,kind="scatter") # scatterplot to display how energy relates to emotional positivty

sb.displot(df["Valence"], bins=10) # histogram to show how valence distrubtes across different songs

sb.relplot(x="Tempo", y="Energy", data=df, kind="scatter") # scatterplot to show if faster songs have higher energy, comparing BPM to intensity

plt.show() # displays the data